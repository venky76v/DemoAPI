var sql = require('mssql');

var connect = function()
{
    var conn = new sql.ConnectionPool({
        user: 'developer',
        password: 'developer1',
        server: 'ws0362ho',
        database: 'TestDB'
    });
    return conn;
};

module.exports = connect;