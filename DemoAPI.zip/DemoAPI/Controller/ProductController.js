var express = require('express');
var router = express.Router();
var sql = require('mssql');
var conn = require('../connection/connect')();

var routes = function () {
    
    router.route('/')
        .get(function (req, res){
            conn.connect().then(function ()
            {
                var sqlQuery = "Select * from products";
                var req = new sql.Request(conn);
                req.query(sqlQuery).then(function (recorset){
                    res.json(recorset.recordset);
                    conn.close()
                })
                .catch(function (err){
                    conn.close();
                    res.status(400).send("Error while fetching data from SQL server");
                });
            })
            .catch(function (err) {
                conn.close();
                res.status(400).send("Error while connecting to SQL server");
            });
        });

        router.route('/')
            .post(function (req, res){
                conn.connect().then(function () {
                    var transaction = new sql.Transaction(conn);
                    transaction.begin().then(function () {
                        var request = new sql.Request(transaction);
                        request.input("ProductName", sql.VarChar(50), req.body.ProductName);
                        request.input("ProductPrice", sql.Decimal(18,0), req.body.ProductPrice);
                        request.execute("usp_InsertProduct").then(function () {
                            transaction.commit().then(function (recordset) {
                                conn.close();
                                res.status(200).send(req.body);
                            }).catch(function (err) {
                                conn.close();
                                res.status(400).send("1. Some Error occurred while inserting data");
                            });
                        }).catch(function (err){
                            conn.close();
                            res.status(400).send("2. Some Error occurred while inserting data");                            
                        }).catch(function (err){
                            conn.close();
                            res.status(400).send("3. Some Error occurred while inserting data");
                        }).catch(function (err){
                            conn.close();
                            res.status(400).send("3. Some Error occurred while inserting data");
                        });
                    });
                });
            });

        router.route('/:id')
            .put(function (req, res) {
                var _productID = req.params.id;
                conn.connect().then(function (){
                    var transaction = new sql.Transaction(conn);
                    transaction.begin().then(function () {
                        var request = new sql.Request(transaction);
                        request.input("ProductID", sql.Int, _productID);
                        request.input("ProductPrice", sql.Decimal(18,0), req.body.ProductPrice);
                        request.execute("usp_UpdateProduct").then(function () {
                            transaction.commit().then(function (recordset) {
                                conn.close();
                                res.status(200).send(req.body);
                            }).catch(function (err) {
                                conn.close();
                                console.log(err);
                                res.status(400).send("1. Error while updating data");
                            });
                        }).catch(function (err) {
                            conn.close();
                            console.log(err);
                            res.status(400).send("2. Error while updating data");                            
                        });
                    }).catch(function (err) {
                        conn.close();
                        console.log(err);
                        res.status(400).send("1. Error while updating data");                        
                    });
                }).catch(function (err) {
                    conn.close();
                    console.log(err);
                    res.status(400).send("1. Error while updating data");                    
                });
            });

            router.route('/:id')
                .delete(function (req, res) {
                    var _productID = req.params.id;
                    console.log(_productID);
                    conn.connect().then(function (){
                        var transaction = new sql.Transaction(conn);
                        transaction.begin().then(function () {
                            var request = new sql.Request(transaction);
                            request.input("ProductID", sql.Int, _productID);
                            request.execute("usp_DeleteProduct").then(function () {
                                transaction.commit().then(function (recordset) {
                                    conn.close();
                                    res.status(200).json("Product id: " + _productID + " Deleted from database");
                                }).catch(function (err) {
                                    conn.close();
                                    console.log(err);
                                    res.status(400).send("1. Error while deleting data");
                                });
                            }).catch(function (err) {
                                conn.close();
                                console.log(err);
                                res.status(400).send("2. Error while deleting data");
                            });
                        }).catch(function (err) {
                            conn.close();
                            console.log(err);
                            res.status(400).send("3. Error while deleting data");
                        });
                    }).catch(function () {
                        conn.close();
                        console.log(err);
                        res.status(400).send("4. Error while deleting data");
                    });
                });

        return router;
};

module.exports = routes;